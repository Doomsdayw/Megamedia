# MegaMedusa Machine V3.3.1 

### - About :
 MegaMedusa is NodeJS DDoS Machine Layer-7 provided by RipperSec Team.

### - Refference : 
https://t.me/MegaMedusaLog
 
### - MegaMedusa Security Bypass :
- HTTP Bypass
- UAM Bypass
- Simple Captcha Bypass
- DDoS Guard Bypass

### - Usage :
```
Usage: node MegaMedusa https://example.com 300 30 10 proxy.txt
````

### - Installations :
 ```
git clone https://github.com/TrashDono/MegaMedusa
cd MegaMedusa
python3 nvminstall.py
python3 installer.py
```
### - OS / Kernel Support :
- Termux 
- Kali Kernel
- Windows

### - Donation (BTC) :
 ```
bc1q5z9kccxvwcx6dk9hsmezvhfg8yqjyj0hs3v52v
 ```

## Disclaimer :
This Project Only For Pen-testing And Not Allowed To Attack Any Website Without Owner Permissions.
We not responsible for harm usage.
